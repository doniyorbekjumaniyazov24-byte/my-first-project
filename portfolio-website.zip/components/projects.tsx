import { ExternalLink, Github, Folder } from "lucide-react"
import Link from "next/link"

const featuredProjects = [
  {
    title: "Cloud Dashboard",
    description:
      "A comprehensive cloud infrastructure management dashboard with real-time monitoring, alerting, and cost optimization features. Built with a focus on performance and user experience.",
    technologies: ["Next.js", "TypeScript", "PostgreSQL", "Tailwind CSS", "Chart.js"],
    github: "https://github.com",
    external: "https://example.com",
  },
  {
    title: "AI Content Platform",
    description:
      "An AI-powered content generation and management platform that helps marketing teams create, optimize, and distribute content at scale with advanced analytics.",
    technologies: ["React", "Node.js", "OpenAI API", "MongoDB", "Redis"],
    github: "https://github.com",
    external: "https://example.com",
  },
  {
    title: "E-Commerce Storefront",
    description:
      "A modern, headless e-commerce solution with advanced filtering, real-time inventory, and seamless checkout experience. Optimized for conversion and accessibility.",
    technologies: ["Next.js", "Stripe", "Sanity CMS", "Vercel", "Tailwind CSS"],
    github: "https://github.com",
    external: "https://example.com",
  },
]

const otherProjects = [
  {
    title: "Component Library",
    description: "A collection of reusable React components with TypeScript support and comprehensive documentation.",
    technologies: ["React", "TypeScript", "Storybook"],
    github: "https://github.com",
  },
  {
    title: "CLI Task Manager",
    description: "A command-line task management tool with natural language processing for quick task entry.",
    technologies: ["Node.js", "Commander.js", "SQLite"],
    github: "https://github.com",
  },
  {
    title: "Weather App",
    description: "A minimal weather application with location-based forecasts and beautiful visualizations.",
    technologies: ["React", "OpenWeather API", "Framer Motion"],
    github: "https://github.com",
    external: "https://example.com",
  },
  {
    title: "Portfolio Generator",
    description: "A tool that generates portfolio websites from a simple configuration file.",
    technologies: ["Next.js", "MDX", "Tailwind CSS"],
    github: "https://github.com",
  },
  {
    title: "Markdown Editor",
    description: "A distraction-free markdown editor with live preview and export options.",
    technologies: ["React", "CodeMirror", "Remark"],
    github: "https://github.com",
    external: "https://example.com",
  },
  {
    title: "API Rate Limiter",
    description: "A flexible rate limiting middleware for Node.js applications with Redis support.",
    technologies: ["Node.js", "Redis", "Express"],
    github: "https://github.com",
  },
]

export function Projects() {
  return (
    <section id="projects" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-12">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground whitespace-nowrap">
            Featured Projects
          </h2>
          <div className="h-px bg-border flex-1" />
        </div>

        {/* Featured Projects */}
        <div className="space-y-24 mb-24">
          {featuredProjects.map((project, index) => (
            <div
              key={project.title}
              className={`relative grid md:grid-cols-12 gap-4 items-center ${
                index % 2 === 1 ? "md:text-right" : ""
              }`}
            >
              {/* Project Image Placeholder */}
              <div
                className={`md:col-span-7 aspect-video rounded-lg bg-card border border-border overflow-hidden ${
                  index % 2 === 1 ? "md:col-start-6 md:row-start-1" : ""
                }`}
              >
                <div className="w-full h-full flex items-center justify-center text-muted-foreground/30 text-4xl font-bold bg-gradient-to-br from-primary/5 to-primary/10">
                  {project.title.split(" ").map(w => w[0]).join("")}
                </div>
              </div>

              {/* Project Content */}
              <div
                className={`md:col-span-6 md:row-start-1 space-y-4 ${
                  index % 2 === 1
                    ? "md:col-start-1 md:text-left"
                    : "md:col-start-6 md:text-right"
                }`}
              >
                <p className="text-sm font-mono text-primary">Featured Project</p>
                <h3 className="text-2xl font-bold text-foreground">
                  {project.title}
                </h3>
                <div className="bg-card p-6 rounded-lg shadow-lg border border-border">
                  <p className="text-muted-foreground leading-relaxed">
                    {project.description}
                  </p>
                </div>
                <ul
                  className={`flex flex-wrap gap-3 text-sm font-mono text-muted-foreground ${
                    index % 2 === 1 ? "md:justify-start" : "md:justify-end"
                  }`}
                >
                  {project.technologies.map((tech) => (
                    <li key={tech}>{tech}</li>
                  ))}
                </ul>
                <div
                  className={`flex gap-4 ${
                    index % 2 === 1 ? "md:justify-start" : "md:justify-end"
                  }`}
                >
                  {project.github && (
                    <Link
                      href={project.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label="GitHub repository"
                      className="text-foreground hover:text-primary transition-colors"
                    >
                      <Github className="h-5 w-5" />
                    </Link>
                  )}
                  {project.external && (
                    <Link
                      href={project.external}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label="Live project"
                      className="text-foreground hover:text-primary transition-colors"
                    >
                      <ExternalLink className="h-5 w-5" />
                    </Link>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Other Projects */}
        <div className="text-center mb-12">
          <h3 className="text-xl font-bold text-foreground">
            Other Noteworthy Projects
          </h3>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {otherProjects.map((project) => (
            <div
              key={project.title}
              className="group bg-card p-6 rounded-lg border border-border hover:border-primary/50 transition-all duration-300 hover:-translate-y-1"
            >
              <div className="flex items-center justify-between mb-6">
                <Folder className="h-10 w-10 text-primary" />
                <div className="flex gap-3">
                  {project.github && (
                    <Link
                      href={project.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label="GitHub repository"
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      <Github className="h-5 w-5" />
                    </Link>
                  )}
                  {project.external && (
                    <Link
                      href={project.external}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label="Live project"
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      <ExternalLink className="h-5 w-5" />
                    </Link>
                  )}
                </div>
              </div>
              <h4 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors mb-2">
                {project.title}
              </h4>
              <p className="text-muted-foreground text-sm mb-6 leading-relaxed">
                {project.description}
              </p>
              <ul className="flex flex-wrap gap-2 text-xs font-mono text-muted-foreground">
                {project.technologies.map((tech) => (
                  <li key={tech}>{tech}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
