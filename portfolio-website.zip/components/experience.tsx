"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

const experiences = [
  {
    company: "TechCorp",
    role: "Senior Frontend Engineer",
    period: "2023 — Present",
    description: [
      "Lead development of customer-facing web applications using React, TypeScript, and Next.js",
      "Architect and implement scalable frontend solutions serving 100k+ daily active users",
      "Mentor junior developers and establish best practices for code quality and accessibility",
      "Collaborate with designers and product managers to deliver exceptional user experiences",
    ],
    technologies: ["React", "TypeScript", "Next.js", "GraphQL", "Tailwind CSS"],
  },
  {
    company: "Digital Agency",
    role: "Full Stack Developer",
    period: "2021 — 2023",
    description: [
      "Built and maintained web applications for diverse clients across multiple industries",
      "Developed RESTful APIs and integrated third-party services using Node.js",
      "Implemented responsive designs and improved Core Web Vitals across all projects",
      "Led technical discovery sessions and created project estimates for new business pitches",
    ],
    technologies: ["Vue.js", "Node.js", "PostgreSQL", "AWS", "Docker"],
  },
  {
    company: "StartupXYZ",
    role: "Junior Developer",
    period: "2019 — 2021",
    description: [
      "Contributed to the development of the company&apos;s flagship SaaS product",
      "Worked closely with the CTO to implement new features and fix bugs",
      "Participated in code reviews and learned industry best practices",
      "Helped establish the company&apos;s component library and design system",
    ],
    technologies: ["JavaScript", "React", "Express", "MongoDB", "CSS"],
  },
]

export function Experience() {
  const [activeTab, setActiveTab] = useState(0)

  return (
    <section id="experience" className="py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-12">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground whitespace-nowrap">
            Experience
          </h2>
          <div className="h-px bg-border flex-1" />
        </div>

        <div className="grid md:grid-cols-[200px_1fr] gap-8">
          {/* Tab List */}
          <div className="flex md:flex-col overflow-x-auto md:overflow-visible border-b md:border-b-0 md:border-l border-border">
            {experiences.map((exp, index) => (
              <button
                key={exp.company}
                onClick={() => setActiveTab(index)}
                className={cn(
                  "px-4 py-3 text-left text-sm font-medium transition-colors whitespace-nowrap",
                  "border-b-2 md:border-b-0 md:border-l-2 -mb-px md:mb-0 md:-ml-px",
                  activeTab === index
                    ? "text-primary border-primary bg-primary/5"
                    : "text-muted-foreground border-transparent hover:text-foreground hover:bg-muted/50"
                )}
              >
                {exp.company}
              </button>
            ))}
          </div>

          {/* Tab Panel */}
          <div className="min-h-[300px]">
            {experiences.map((exp, index) => (
              <div
                key={exp.company}
                className={cn(
                  "space-y-4",
                  activeTab === index ? "block" : "hidden"
                )}
              >
                <div>
                  <h3 className="text-xl font-semibold text-foreground">
                    {exp.role}{" "}
                    <span className="text-primary">@ {exp.company}</span>
                  </h3>
                  <p className="text-sm text-muted-foreground font-mono mt-1">
                    {exp.period}
                  </p>
                </div>
                <ul className="space-y-3">
                  {exp.description.map((item, i) => (
                    <li key={i} className="flex gap-3 text-muted-foreground">
                      <span className="text-primary mt-1.5 flex-shrink-0">▹</span>
                      <span dangerouslySetInnerHTML={{ __html: item.replace(/&apos;/g, "'") }} />
                    </li>
                  ))}
                </ul>
                <div className="flex flex-wrap gap-2 pt-2">
                  {exp.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-3 py-1 text-xs font-medium bg-primary/10 text-primary rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
