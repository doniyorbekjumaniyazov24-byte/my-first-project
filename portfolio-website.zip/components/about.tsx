const skills = [
  "JavaScript (ES6+)",
  "TypeScript",
  "React",
  "Next.js",
  "Node.js",
  "PostgreSQL",
  "Tailwind CSS",
  "GraphQL",
]

export function About() {
  return (
    <section id="about" className="py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-12">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground whitespace-nowrap">
            About Me
          </h2>
          <div className="h-px bg-border flex-1" />
        </div>

        <div className="grid md:grid-cols-3 gap-12">
          <div className="md:col-span-2 space-y-4 text-muted-foreground leading-relaxed">
            <p>
              I&apos;m a developer passionate about building accessible, human-centered 
              software. My interest in web development started years ago when I decided 
              to customize a blog template — turns out hacking together HTML and CSS 
              taught me a lot about how the web works!
            </p>
            <p>
              Fast-forward to today, and I&apos;ve had the privilege of working at{" "}
              <span className="text-primary font-medium">a startup</span>,{" "}
              <span className="text-primary font-medium">a large corporation</span>, and{" "}
              <span className="text-primary font-medium">a digital agency</span>. My 
              main focus these days is building accessible, inclusive products and 
              digital experiences for a variety of clients.
            </p>
            <p>
              When I&apos;m not at the computer, I enjoy hiking, photography, 
              and exploring new coffee shops around the city.
            </p>
            <p className="pt-2">
              Here are a few technologies I&apos;ve been working with recently:
            </p>
            <ul className="grid grid-cols-2 gap-2 pt-2">
              {skills.map((skill) => (
                <li key={skill} className="flex items-center gap-2 text-sm">
                  <span className="text-primary">▹</span>
                  {skill}
                </li>
              ))}
            </ul>
          </div>

          <div className="relative group">
            <div className="relative aspect-square rounded-lg overflow-hidden bg-primary/20">
              <div className="absolute inset-0 flex items-center justify-center text-primary/50 text-6xl font-bold">
                AC
              </div>
              <div className="absolute inset-0 bg-primary/20 group-hover:bg-transparent transition-colors duration-300" />
            </div>
            <div className="absolute -inset-2 border-2 border-primary rounded-lg -z-10 translate-x-4 translate-y-4 group-hover:translate-x-2 group-hover:translate-y-2 transition-transform duration-300" />
          </div>
        </div>
      </div>
    </section>
  )
}
