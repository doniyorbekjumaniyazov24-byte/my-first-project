import Link from "next/link"
import { Mail } from "lucide-react"

export function Contact() {
  return (
    <section id="contact" className="py-24 px-6">
      <div className="max-w-2xl mx-auto text-center">
        <p className="text-primary font-mono text-sm mb-4">What&apos;s Next?</p>
        <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
          Get In Touch
        </h2>
        <p className="text-muted-foreground text-lg mb-10 leading-relaxed">
          I&apos;m currently open to new opportunities and would love to hear from you. 
          Whether you have a question, want to collaborate, or just want to say hi, 
          feel free to reach out and I&apos;ll get back to you as soon as I can!
        </p>
        <Link
          href="mailto:hello@example.com"
          className="inline-flex items-center gap-2 px-8 py-4 bg-primary text-primary-foreground font-medium rounded-lg hover:bg-primary/90 transition-colors"
        >
          <Mail className="h-5 w-5" />
          Say Hello
        </Link>
      </div>
    </section>
  )
}
